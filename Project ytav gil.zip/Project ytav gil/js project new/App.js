function AddItem1(){
    let itemAdd = document.getElementById("cartItem1");
    itemAdd.innerHTML = "✖ GTR R35"

    let priceAdd = document.getElementById("cartPrice1");
    priceAdd.innerHTML = "200000"
};

function AddItem2(){
    let itemAdd = document.getElementById("cartItem2");
    itemAdd.innerHTML = "✖ GTR R34"

    let priceAdd = document.getElementById("cartPrice2");
    priceAdd.innerHTML = "70000"
}

function AddItem3(){
    let itemAdd = document.getElementById("cartItem3");
    itemAdd.innerHTML = "✖ GTR R33"

    let priceAdd = document.getElementById("cartPrice3");
    priceAdd.innerHTML = "73000"
}


function AddItem4(){
    let itemAdd = document.getElementById("cartItem4");
    itemAdd.innerHTML = "✖ GTR R32"

    let priceAdd = document.getElementById("cartPrice4");
    priceAdd.innerHTML = "42000"
}

function AddItem5(){
    let itemAdd = document.getElementById("cartItem5");
    itemAdd.innerHTML = "✖ GTR C110"

    let priceAdd = document.getElementById("cartPrice5");
    priceAdd.innerHTML = "43000"
}

function AddItem6(){
    let itemAdd = document.getElementById("cartItem6");
    itemAdd.innerHTML = "✖ GTR C10"

    let priceAdd = document.getElementById("cartPrice6");
    priceAdd.innerHTML = "100000"
}

function Total(){
    let totalValue = document.getElementById("cartTotal");
    
    let value1 = document.getElementById("cartPrice1");
    let value2 = document.getElementById("cartPrice2");
    let value3 = document.getElementById("cartPrice3");
    let value4 = document.getElementById("cartPrice4");
    let value5 = document.getElementById("cartPrice5");
    let value6 = document.getElementById("cartPrice6");


    value1 = Number(value1.innerHTML);
    value2 = Number(value2.innerHTML);
    value3 = Number(value3.innerHTML);
    value4 = Number(value4.innerHTML);
    value5 = Number(value5.innerHTML);
    value6 = Number(value6.innerHTML);
    let totalValueOverall = value1+value2+value3+value4+value5+value6;

    totalValue.innerHTML = totalValueOverall;
}

function RemoveFQ1(){
    let BTN1 = document.getElementById("cartItem1");

    BTN1.innerHTML = "";

    let BTN2 = document.getElementById("cartPrice1");

    BTN2.innerHTML = "";

}

function RemoveFQ2(){
    let BTN1 = document.getElementById("cartItem2");

    BTN1.innerHTML = "";

    let BTN2 = document.getElementById("cartPrice2");

    BTN2.innerHTML = "";

}

function RemoveFQ3(){
    let BTN1 = document.getElementById("cartItem3");

    BTN1.innerHTML = "";

    let BTN2 = document.getElementById("cartPrice3");

    BTN2.innerHTML = "";

}

function RemoveFQ4(){
    let BTN1 = document.getElementById("cartItem4");

    BTN1.innerHTML = "";

    let BTN2 = document.getElementById("cartPrice4");

    BTN2.innerHTML = "";

}

function RemoveFQ5(){
    let BTN1 = document.getElementById("cartItem5");

    BTN1.innerHTML = "";

    let BTN2 = document.getElementById("cartPrice5");

    BTN2.innerHTML = "";

}

function RemoveFQ6(){
    let BTN1 = document.getElementById("cartItem6");

    BTN1.innerHTML = "";

    let BTN2 = document.getElementById("cartPrice6");

    BTN2.innerHTML = "";

}

function PurchaseThanks(){
    let TotalPrice = document.getElementById("cartTotal");
        let TotPz = TotalPrice.innerHTML;
    if(TotalPrice.innerHTML = null || TotalPrice.innerHTML == 0){
        alert("Please choose a product before pressing purchase")
    }
    else
    {
    alert("Your purchase for $" + TotPz + " has been Successful!")
    }
}

function ClearAll(){
    RemoveFQ1();
    RemoveFQ2();
    RemoveFQ3();
    RemoveFQ4();
    RemoveFQ5();
    RemoveFQ6();
}
